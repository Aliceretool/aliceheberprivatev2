<GlobalFunctions>
  <SqlQueryUnified
    id="query1"
    errorTransformer="// The variable 'data' allows you to reference the request's data in the transformer. 
// example: return data.find(element => element.isError)
return data.error"
    query={include("./lib/query1.sql", "string")}
    resourceDisplayName="retool_db"
    resourceName="8e7ce9ed-91a4-46f1-86c3-6c413257e353"
    resourceTypeOverride=""
    transformer="// Query results are available as the `data` variable
return data"
    warningCodes={[]}
    workflowBlockPluginId={null}
  />
  <SqlQueryUnified
    id="query2"
    errorTransformer="// The variable 'data' allows you to reference the request's data in the transformer. 
// example: return data.find(element => element.isError)
return data.error"
    resourceName="[demo resource] PostgreSQL"
    transformer="// Query results are available as the `data` variable
return data"
    workflowBlockPluginId={null}
  />
  <SqlQueryUnified
    id="query4"
    query={include("./lib/query4.sql", "string")}
    resourceDisplayName="Retool DB"
    resourceName="9d052a87-5727-41ac-bb18-caacc0d05b90"
    warningCodes={[]}
  />
  <GraphQLQuery
    id="query5"
    body={include("./lib/query5.gql", "string")}
    resourceName="6cf498fb-1859-42dd-add7-4871824ad324"
  />
</GlobalFunctions>
